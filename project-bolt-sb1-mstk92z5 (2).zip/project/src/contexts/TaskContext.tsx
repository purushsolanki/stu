import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Task, TaskStatus } from '../types';

interface TaskContextType {
  tasks: Task[];
  todaysTasks: Task[];
  completedTasks: Task[];
  updateTaskStatus: (taskId: string, newStatus: TaskStatus) => void;
  syllabusProgress: number;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

// Sample initial tasks
const initialTasks: Task[] = [
  {
    id: '1',
    title: 'Rajasthan History - Medieval Period',
    description: 'Study chapters 3-5 from the textbook',
    status: 'pending',
    scheduledTime: new Date(new Date().setHours(9, 0, 0)).toISOString(),
    subject: 'History'
  },
  {
    id: '2',
    title: 'Indian Constitution Quiz',
    description: 'Complete 50 practice questions',
    status: 'pending',
    scheduledTime: new Date(new Date().setHours(11, 30, 0)).toISOString(),
    subject: 'Polity'
  },
  {
    id: '3',
    title: 'Geography - Climate of Rajasthan',
    description: 'Read chapter 7 and make notes',
    status: 'in-progress',
    scheduledTime: new Date(new Date().setHours(14, 0, 0)).toISOString(),
    subject: 'Geography'
  },
  {
    id: '4',
    title: 'Current Affairs - February 2025',
    description: 'Review monthly compilation',
    status: 'pending',
    scheduledTime: new Date(new Date().setHours(16, 30, 0)).toISOString(),
    subject: 'Current Affairs'
  },
  {
    id: '5',
    title: 'Arithmetic Problems',
    description: 'Solve 20 practice problems on percentages',
    status: 'completed',
    scheduledTime: new Date(new Date().setHours(8, 0, 0)).toISOString(),
    completedAt: new Date(new Date().setHours(8, 45, 0)).toISOString(),
    subject: 'Mathematics'
  }
];

export const TaskProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [syllabusProgress, setSyllabusProgress] = useState<number>(42);

  // Filter today's tasks (pending and in-progress)
  const todaysTasks = tasks.filter(
    task => task.status === 'pending' || task.status === 'in-progress'
  ).sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());

  // Filter completed tasks
  const completedTasks = tasks.filter(
    task => task.status === 'completed'
  ).sort((a, b) => {
    if (a.completedAt && b.completedAt) {
      return new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime();
    }
    return 0;
  });

  // Update task status
  const updateTaskStatus = (taskId: string, newStatus: TaskStatus) => {
    setTasks(prevTasks => 
      prevTasks.map(task => {
        if (task.id === taskId) {
          const updatedTask = { 
            ...task, 
            status: newStatus,
            // If task is completed, add completion timestamp
            ...(newStatus === 'completed' ? { completedAt: new Date().toISOString() } : {})
          };
          return updatedTask;
        }
        return task;
      })
    );

    // Update syllabus progress when tasks are completed
    if (newStatus === 'completed') {
      setSyllabusProgress(prev => Math.min(prev + Math.random() * 2, 100));
    }
  };

  // Provide the context value
  const contextValue: TaskContextType = {
    tasks,
    todaysTasks,
    completedTasks,
    updateTaskStatus,
    syllabusProgress
  };

  return (
    <TaskContext.Provider value={contextValue}>
      {children}
    </TaskContext.Provider>
  );
};

// Custom hook to use the task context
export const useTaskContext = (): TaskContextType => {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTaskContext must be used within a TaskProvider');
  }
  return context;
};
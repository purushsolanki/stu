import React, { useState, useEffect } from 'react';
import { calculateTimeRemaining, getMotivationalTip } from '../../utils/dateUtils';
import { CalendarClock } from 'lucide-react';

const CountdownTimer: React.FC = () => {
  // Exam date - August 15, 2025
  const examDate = new Date('2025-08-15T10:00:00');
  const [timeRemaining, setTimeRemaining] = useState(calculateTimeRemaining(examDate));
  const [tip, setTip] = useState(getMotivationalTip());

  // Update countdown timer every second
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining(calculateTimeRemaining(examDate));
    }, 1000);

    // Change tip every hour
    const tipTimer = setInterval(() => {
      setTip(getMotivationalTip());
    }, 3600000);

    return () => {
      clearInterval(timer);
      clearInterval(tipTimer);
    };
  }, []);

  return (
    <div className="bg-white rounded-xl shadow-md p-4 mb-5 transition-all duration-300 hover:shadow-lg">
      <div className="flex items-center mb-3">
        <CalendarClock className="text-blue-600 mr-2" size={22} />
        <h2 className="text-lg font-medium text-gray-800">Countdown to Exam</h2>
      </div>
      
      <div className="flex justify-between mb-3">
        <div className="text-center px-3 py-2 bg-blue-50 rounded-lg flex-1 mx-1">
          <div className="text-2xl font-bold text-blue-700">{timeRemaining.days}</div>
          <div className="text-xs text-gray-600">Days</div>
        </div>
        <div className="text-center px-3 py-2 bg-blue-50 rounded-lg flex-1 mx-1">
          <div className="text-2xl font-bold text-blue-700">{timeRemaining.hours}</div>
          <div className="text-xs text-gray-600">Hours</div>
        </div>
        <div className="text-center px-3 py-2 bg-blue-50 rounded-lg flex-1 mx-1">
          <div className="text-2xl font-bold text-blue-700">{timeRemaining.minutes}</div>
          <div className="text-xs text-gray-600">Minutes</div>
        </div>
        <div className="text-center px-3 py-2 bg-blue-50 rounded-lg flex-1 mx-1">
          <div className="text-2xl font-bold text-blue-700">{timeRemaining.seconds}</div>
          <div className="text-xs text-gray-600">Seconds</div>
        </div>
      </div>
      
      <div className="text-sm italic text-gray-600 px-2 py-1 bg-yellow-50 rounded-md">
        <p className="text-center">{tip}</p>
      </div>
      
      <div className="mt-2 text-xs text-center text-gray-500">
        Exam Date: August 15, 2025
      </div>
    </div>
  );
};

export default CountdownTimer;
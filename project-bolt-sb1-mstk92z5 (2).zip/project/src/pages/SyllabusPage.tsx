import React from 'react';
import { BookOpen, CheckCircle, ChevronRight } from 'lucide-react';

const SyllabusPage: React.FC = () => {
  const subjects = [
    {
      name: 'Rajasthan History',
      progress: 65,
      topics: 14,
      completedTopics: 9
    },
    {
      name: 'Indian Constitution',
      progress: 40,
      topics: 12,
      completedTopics: 5
    },
    {
      name: 'Geography',
      progress: 30,
      topics: 10,
      completedTopics: 3
    },
    {
      name: 'Current Affairs',
      progress: 50,
      topics: 8,
      completedTopics: 4
    },
    {
      name: 'Mathematics',
      progress: 25,
      topics: 15,
      completedTopics: 4
    }
  ];

  return (
    <div className="max-w-lg mx-auto p-4 pb-20">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Syllabus</h1>
        <p className="text-gray-600">Track your syllabus progress</p>
      </header>
      
      <div className="bg-white rounded-xl shadow-md p-4 mb-5">
        <div className="flex items-center mb-3">
          <BookOpen className="text-blue-600 mr-2" size={22} />
          <h2 className="text-lg font-medium text-gray-800">Overall Progress</h2>
          <span className="ml-auto text-blue-700 font-semibold">42%</span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
          <div 
            className="bg-blue-600 h-3 rounded-full" 
            style={{ width: '42%' }}
          />
        </div>
        
        <p className="text-sm text-gray-600">
          25 of 59 topics completed
        </p>
      </div>
      
      <div className="space-y-4">
        {subjects.map((subject, index) => (
          <div key={index} className="bg-white rounded-xl shadow-md p-4 transition-all duration-300 hover:shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-gray-800">{subject.name}</h3>
              <div className="flex items-center">
                <span className="text-sm text-blue-700 font-medium mr-2">{subject.progress}%</span>
                <ChevronRight size={18} className="text-gray-400" />
              </div>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-1000 ease-out" 
                style={{ width: `${subject.progress}%` }}
              />
            </div>
            
            <div className="flex items-center text-sm text-gray-600">
              <CheckCircle size={16} className="text-green-600 mr-1" />
              <span>{subject.completedTopics} of {subject.topics} topics</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SyllabusPage;
import React, { useState } from 'react';
import { User, Settings, Clock, LogOut, TrendingUp, BookOpen, Bell, Moon, Volume2, Phone, Mail, Globe2, Crown } from 'lucide-react';

const AccountPage: React.FC = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [showOtpModal, setShowOtpModal] = useState(false);
  
  const user = {
    name: 'Rahul Sharma',
    email: 'rahul.sharma@example.com',
    phone: '+91 98765 43210',
    joinedDate: 'March 15, 2025',
    totalStudyHours: 87,
    averageScore: 76,
    subscription: {
      plan: 'Free Plan',
      expiresAt: 'N/A',
      features: ['Basic Content', 'Limited Mock Tests']
    }
  };

  return (
    <div className="max-w-lg mx-auto p-4 pb-20">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">My Account</h1>
        <p className="text-gray-600">Manage your profile and preferences</p>
      </header>
      
      {/* Profile Card */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl shadow-md p-5 mb-5">
        <div className="flex items-center">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white mr-4">
            <User size={32} />
          </div>
          <div className="text-white flex-1">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-medium">{user.name}</h2>
              <button 
                onClick={() => setIsEditing(true)}
                className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-full transition-colors duration-200"
              >
                Edit Profile
              </button>
            </div>
            <div className="space-y-1 mt-2">
              <div className="flex items-center text-blue-100">
                <Mail size={14} className="mr-2" />
                <span className="text-sm">{user.email}</span>
              </div>
              <div className="flex items-center text-blue-100">
                <Phone size={14} className="mr-2" />
                <span className="text-sm">{user.phone}</span>
              </div>
            </div>
            <p className="text-sm text-blue-100/80 mt-2">Member since {user.joinedDate}</p>
          </div>
        </div>
      </div>
      
      {/* Subscription Card */}
      <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-xl shadow-md p-4 mb-5">
        <div className="flex items-center mb-3">
          <Crown className="text-amber-600 mr-2" size={22} />
          <h2 className="text-lg font-medium text-gray-800">Subscription Plan</h2>
        </div>
        <div className="flex justify-between items-center mb-3">
          <div>
            <p className="text-gray-700 font-medium">{user.subscription.plan}</p>
            <p className="text-sm text-gray-600">Expires: {user.subscription.expiresAt}</p>
          </div>
          <button className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200">
            Upgrade Plan
          </button>
        </div>
        <div className="text-sm text-gray-600">
          <p className="font-medium mb-1">Included Features:</p>
          <ul className="list-disc list-inside space-y-1">
            {user.subscription.features.map((feature, index) => (
              <li key={index}>{feature}</li>
            ))}
          </ul>
        </div>
      </div>

      {/* Progress Stats */}
      <div className="bg-white rounded-xl shadow-md p-4 mb-5">
        <div className="flex items-center mb-4">
          <TrendingUp className="text-blue-600 mr-2" size={22} />
          <h2 className="text-lg font-medium text-gray-800">Study Progress</h2>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4">
            <div className="flex items-center text-blue-700 mb-2">
              <Clock size={18} className="mr-2" />
              <p className="text-sm font-medium">Total Study Hours</p>
            </div>
            <p className="text-2xl font-bold text-blue-800">{user.totalStudyHours}</p>
            <p className="text-sm text-blue-600">hours completed</p>
          </div>
          
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4">
            <div className="flex items-center text-green-700 mb-2">
              <BookOpen size={18} className="mr-2" />
              <p className="text-sm font-medium">Average Score</p>
            </div>
            <p className="text-2xl font-bold text-green-800">{user.averageScore}%</p>
            <p className="text-sm text-green-600">in mock tests</p>
          </div>
        </div>
      </div>
      
      {/* Settings */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-5">
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center">
            <Settings className="text-blue-600 mr-3" size={20} />
            <span className="text-gray-800 font-medium">Preferences</span>
          </div>
        </div>
        
        <div className="divide-y divide-gray-100">
          <div className="p-4 flex justify-between items-center hover:bg-gray-50 transition-colors duration-200">
            <div className="flex items-center">
              <Bell size={18} className="text-gray-500 mr-3" />
              <div>
                <span className="text-gray-800 font-medium">Daily Reminder</span>
                <p className="text-xs text-gray-500">Get notified about your daily tasks</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" value="" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          
          <div className="p-4 flex justify-between items-center hover:bg-gray-50 transition-colors duration-200">
            <div className="flex items-center">
              <Moon size={18} className="text-gray-500 mr-3" />
              <div>
                <span className="text-gray-800 font-medium">Dark Mode</span>
                <p className="text-xs text-gray-500">Switch to dark theme</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" value="" className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          
          <div className="p-4 flex justify-between items-center hover:bg-gray-50 transition-colors duration-200">
            <div className="flex items-center">
              <Volume2 size={18} className="text-gray-500 mr-3" />
              <div>
                <span className="text-gray-800 font-medium">Sound Effects</span>
                <p className="text-xs text-gray-500">Play sounds for notifications</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" value="" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="p-4 flex justify-between items-center hover:bg-gray-50 transition-colors duration-200">
            <div className="flex items-center">
              <Globe2 size={18} className="text-gray-500 mr-3" />
              <div>
                <span className="text-gray-800 font-medium">Language</span>
                <p className="text-xs text-gray-500">Choose your preferred language</p>
              </div>
            </div>
            <select className="bg-gray-100 text-gray-800 text-sm rounded-lg px-3 py-1.5 border-gray-200 focus:ring-blue-500 focus:border-blue-500">
              <option value="en">English</option>
              <option value="hi">हिंदी</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Sign Out Button */}
      <button className="w-full py-3 flex items-center justify-center text-white bg-red-500 hover:bg-red-600 rounded-lg transition-colors duration-300 font-medium">
        <LogOut size={18} className="mr-2" />
        Sign Out
      </button>

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Edit Profile</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input 
                  type="text" 
                  defaultValue={user.name}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <div className="flex gap-2">
                  <input 
                    type="email" 
                    defaultValue={user.email}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  />
                  <button 
                    onClick={() => setShowOtpModal(true)}
                    className="px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors duration-200"
                  >
                    Verify
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                <div className="flex gap-2">
                  <input 
                    type="tel" 
                    defaultValue={user.phone}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  />
                  <button 
                    onClick={() => setShowOtpModal(true)}
                    className="px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors duration-200"
                  >
                    Verify
                  </button>
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button 
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors duration-200"
              >
                Cancel
              </button>
              <button 
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* OTP Verification Modal */}
      {showOtpModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Enter OTP</h3>
            <p className="text-gray-600 text-sm mb-4">
              We've sent a verification code to your email/phone. Please enter it below.
            </p>
            <div className="flex gap-2 mb-4">
              {[1, 2, 3, 4, 5, 6].map((_, index) => (
                <input
                  key={index}
                  type="text"
                  maxLength={1}
                  className="w-12 h-12 text-center border border-gray-300 rounded-lg text-xl focus:ring-blue-500 focus:border-blue-500"
                />
              ))}
            </div>
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setShowOtpModal(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors duration-200"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  setShowOtpModal(false);
                  // Handle OTP verification
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                Verify
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountPage;
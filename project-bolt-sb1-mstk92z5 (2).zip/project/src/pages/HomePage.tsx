import React from 'react';
import CountdownTimer from '../components/home/CountdownTimer';
import ProgressOverview from '../components/home/ProgressOverview';
import TaskList from '../components/home/TaskList';

const HomePage: React.FC = () => {
  return (
    <div className="max-w-lg mx-auto p-4 pb-20">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Patwari Exam Prep</h1>
        <p className="text-gray-600">Your personalized study dashboard</p>
      </header>
      
      <CountdownTimer />
      <ProgressOverview />
      <TaskList type="upcoming" />
      <TaskList type="completed" />
    </div>
  );
};

export default HomePage;
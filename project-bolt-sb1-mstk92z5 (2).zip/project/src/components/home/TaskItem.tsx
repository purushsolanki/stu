import React from 'react';
import { Clock, CheckCircle2 } from 'lucide-react';
import { Task, TaskStatus } from '../../types';
import { formatTime } from '../../utils/dateUtils';
import { useTaskContext } from '../../contexts/TaskContext';

interface TaskItemProps {
  task: Task;
}

const TaskItem: React.FC<TaskItemProps> = ({ task }) => {
  const { updateTaskStatus } = useTaskContext();

  // Status colors and icons
  const statusConfig = {
    'pending': {
      bgColor: 'bg-gray-50',
      borderColor: 'border-gray-200',
      textColor: 'text-gray-800',
      icon: <div className="w-5 h-5 border-2 border-gray-400 rounded-full"></div>
    },
    'in-progress': {
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-200',
      textColor: 'text-amber-800',
      icon: <div className="w-5 h-5 border-2 border-amber-500 rounded-full">
              <div className="w-2.5 h-2.5 bg-amber-500 rounded-full m-auto mt-0.5"></div>
            </div>
    },
    'completed': {
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      textColor: 'text-green-800',
      icon: <CheckCircle2 className="w-5 h-5 text-green-600" />
    }
  };

  const config = statusConfig[task.status];

  // Handle status change
  const handleStatusChange = (newStatus: TaskStatus) => {
    updateTaskStatus(task.id, newStatus);
  };

  return (
    <div className={`p-3 mb-3 border rounded-lg ${config.bgColor} ${config.borderColor} transition-all duration-300`}>
      <div className="flex items-start mb-2">
        <div className="mr-3 mt-1 cursor-pointer" onClick={() => {
          const nextStatus: Record<TaskStatus, TaskStatus> = {
            'pending': 'in-progress',
            'in-progress': 'completed',
            'completed': 'pending'
          };
          handleStatusChange(nextStatus[task.status]);
        }}>
          {config.icon}
        </div>
        
        <div className="flex-1">
          <h3 className={`font-medium ${config.textColor}`}>{task.title}</h3>
          {task.description && (
            <p className="text-sm text-gray-600 mt-1">{task.description}</p>
          )}
        </div>
      </div>
      
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center text-gray-500">
          <Clock size={14} className="mr-1" />
          <span>{formatTime(task.scheduledTime)}</span>
        </div>
        
        {task.subject && (
          <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
            {task.subject}
          </span>
        )}
        
        {task.status !== 'completed' && (
          <div className="flex space-x-1">
            <button 
              onClick={() => handleStatusChange('pending')}
              className={`px-2 py-0.5 rounded ${task.status === 'pending' ? 'bg-gray-200' : 'bg-gray-100 hover:bg-gray-200'}`}
            >
              Pending
            </button>
            <button 
              onClick={() => handleStatusChange('in-progress')}
              className={`px-2 py-0.5 rounded ${task.status === 'in-progress' ? 'bg-amber-200' : 'bg-amber-100 hover:bg-amber-200'}`}
            >
              In Progress
            </button>
            <button 
              onClick={() => handleStatusChange('completed')}
              className={`px-2 py-0.5 rounded bg-green-100 hover:bg-green-200`}
            >
              Complete
            </button>
          </div>
        )}
        
        {task.status === 'completed' && task.completedAt && (
          <div className="text-green-600 flex items-center">
            <CheckCircle2 size={14} className="mr-1" />
            <span>Completed at {formatTime(task.completedAt)}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskItem;
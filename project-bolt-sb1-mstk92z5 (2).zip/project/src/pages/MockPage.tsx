import React from 'react';
import { PenTool, Clock, TrendingUp, Medal } from 'lucide-react';

const MockPage: React.FC = () => {
  const mockTests = [
    {
      id: 1,
      title: 'Full Length Mock Test #1',
      questions: 150,
      duration: 120,
      attempted: true,
      score: 82
    },
    {
      id: 2,
      title: 'Rajasthan History Quiz',
      questions: 50,
      duration: 30,
      attempted: true,
      score: 76
    },
    {
      id: 3,
      title: 'Full Length Mock Test #2',
      questions: 150,
      duration: 120,
      attempted: false
    },
    {
      id: 4,
      title: 'Current Affairs Quiz',
      questions: 25,
      duration: 20,
      attempted: false
    }
  ];

  return (
    <div className="max-w-lg mx-auto p-4 pb-20">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Mock Tests</h1>
        <p className="text-gray-600">Practice with test simulations</p>
      </header>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
          <div className="text-blue-700 mb-2">
            <TrendingUp size={20} />
          </div>
          <p className="text-sm text-gray-600">Average Score</p>
          <p className="text-xl font-bold text-blue-800">79%</p>
        </div>
        
        <div className="bg-green-50 rounded-xl p-4 border border-green-100">
          <div className="text-green-700 mb-2">
            <Medal size={20} />
          </div>
          <p className="text-sm text-gray-600">Tests Completed</p>
          <p className="text-xl font-bold text-green-800">2/4</p>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md p-4 mb-5">
        <div className="flex items-center mb-3">
          <PenTool className="text-blue-600 mr-2" size={22} />
          <h2 className="text-lg font-medium text-gray-800">Available Tests</h2>
        </div>
        
        <div className="space-y-4">
          {mockTests.map((test) => (
            <div 
              key={test.id} 
              className={`p-3 rounded-lg border ${
                test.attempted 
                  ? 'bg-gray-50 border-gray-200' 
                  : 'bg-white border-blue-200 hover:border-blue-300'
              } transition-all duration-300`}
            >
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-gray-800">{test.title}</h3>
                {test.attempted ? (
                  <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                    Completed
                  </span>
                ) : (
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                    Available
                  </span>
                )}
              </div>
              
              <div className="flex text-sm text-gray-600 mb-2">
                <div className="flex items-center mr-4">
                  <PenTool size={14} className="mr-1" />
                  <span>{test.questions} questions</span>
                </div>
                <div className="flex items-center">
                  <Clock size={14} className="mr-1" />
                  <span>{test.duration} min</span>
                </div>
              </div>
              
              {test.attempted ? (
                <div className="flex items-center">
                  <div className="flex-1 mr-4">
                    <div className="text-xs text-gray-500 mb-1">Your Score</div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          test.score >= 80 ? 'bg-green-600' : 
                          test.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${test.score}%` }}
                      />
                    </div>
                  </div>
                  <div className="text-lg font-bold text-blue-700">{test.score}%</div>
                </div>
              ) : (
                <button className="w-full mt-2 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors duration-300">
                  Start Test
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MockPage;
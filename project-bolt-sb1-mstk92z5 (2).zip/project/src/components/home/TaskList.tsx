import React from 'react';
import { CheckSquare, ListTodo } from 'lucide-react';
import TaskItem from './TaskItem';
import { useTaskContext } from '../../contexts/TaskContext';

interface TaskListProps {
  type: 'upcoming' | 'completed';
}

const TaskList: React.FC<TaskListProps> = ({ type }) => {
  const { todaysTasks, completedTasks } = useTaskContext();
  
  const tasks = type === 'upcoming' ? todaysTasks : completedTasks;
  const icon = type === 'upcoming' ? 
    <ListTodo className="text-blue-600 mr-2" size={22} /> : 
    <CheckSquare className="text-green-600 mr-2" size={22} />;
  
  const title = type === 'upcoming' ? "Today's Target" : "Completed Tasks Today";
  const emptyMessage = type === 'upcoming' ? 
    "No pending tasks for today!" : 
    "You haven't completed any tasks yet today.";
  
  return (
    <div className="bg-white rounded-xl shadow-md p-4 mb-5 transition-all duration-300 hover:shadow-lg">
      <div className="flex items-center mb-3">
        {icon}
        <h2 className="text-lg font-medium text-gray-800">{title}</h2>
        <span className="ml-auto bg-gray-100 text-gray-700 text-xs font-medium px-2.5 py-0.5 rounded-full">
          {tasks.length}
        </span>
      </div>
      
      {tasks.length > 0 ? (
        <div className="space-y-2">
          {tasks.map(task => (
            <TaskItem key={task.id} task={task} />
          ))}
        </div>
      ) : (
        <div className="text-center py-6 text-gray-500">
          <p>{emptyMessage}</p>
        </div>
      )}
    </div>
  );
};

export default TaskList;
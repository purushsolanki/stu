import React from 'react';
import { TrendingUp } from 'lucide-react';
import { useTaskContext } from '../../contexts/TaskContext';

const ProgressOverview: React.FC = () => {
  const { syllabusProgress } = useTaskContext();
  
  return (
    <div className="bg-white rounded-xl shadow-md p-4 mb-5 transition-all duration-300 hover:shadow-lg">
      <div className="flex items-center mb-3">
        <TrendingUp className="text-blue-600 mr-2" size={22} />
        <h2 className="text-lg font-medium text-gray-800">Progress Overview</h2>
      </div>
      
      <div className="flex items-center mb-1">
        <span className="text-sm text-gray-600 mr-auto">Syllabus Completion</span>
        <span className="text-sm font-medium text-blue-700">{Math.round(syllabusProgress)}%</span>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
        <div 
          className="bg-blue-600 h-3 rounded-full transition-all duration-1000 ease-out" 
          style={{ width: `${syllabusProgress}%` }}
        />
      </div>
      
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="bg-blue-50 rounded-lg p-2">
          <p className="text-xs text-gray-600">Topics</p>
          <p className="text-lg font-semibold text-blue-700">56/120</p>
        </div>
        <div className="bg-blue-50 rounded-lg p-2">
          <p className="text-xs text-gray-600">Tests</p>
          <p className="text-lg font-semibold text-blue-700">12/25</p>
        </div>
        <div className="bg-blue-50 rounded-lg p-2">
          <p className="text-xs text-gray-600">Days Left</p>
          <p className="text-lg font-semibold text-blue-700">142</p>
        </div>
      </div>
    </div>
  );
};

export default ProgressOverview;
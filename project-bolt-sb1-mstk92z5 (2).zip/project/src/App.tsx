import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { TaskProvider } from './contexts/TaskContext';
import HomePage from './pages/HomePage';
import SyllabusPage from './pages/SyllabusPage';
import MockPage from './pages/MockPage';
import AccountPage from './pages/AccountPage';
import BottomNavigation from './components/layout/BottomNavigation';

function App() {
  return (
    <TaskProvider>
      <Router>
        <div className="min-h-screen bg-gray-100">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/syllabus" element={<SyllabusPage />} />
            <Route path="/mock" element={<MockPage />} />
            <Route path="/account" element={<AccountPage />} />
          </Routes>
          <BottomNavigation />
        </div>
      </Router>
    </TaskProvider>
  );
}

export default App;
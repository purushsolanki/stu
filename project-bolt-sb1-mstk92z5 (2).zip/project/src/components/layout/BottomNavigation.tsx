import React from 'react';
import { Home, BookOpen, PenTool, User } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

const BottomNavigation: React.FC = () => {
  const location = useLocation();
  
  const navItems: NavItem[] = [
    {
      path: '/',
      label: 'Home',
      icon: <Home size={24} />,
    },
    {
      path: '/syllabus',
      label: 'Syllabus',
      icon: <BookOpen size={24} />,
    },
    {
      path: '/mock',
      label: 'Mock',
      icon: <PenTool size={24} />,
    },
    {
      path: '/account',
      label: 'Account',
      icon: <User size={24} />,
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-2 px-4 flex justify-around items-center z-10">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path;
        
        return (
          <Link
            key={item.path}
            to={item.path}
            className={`flex flex-col items-center ${
              isActive 
                ? 'text-blue-600' 
                : 'text-gray-500 hover:text-gray-700'
            } transition-all duration-200`}
          >
            <div className={`p-1 ${isActive ? 'transform scale-110' : ''}`}>
              {item.icon}
            </div>
            <span className={`text-xs mt-1 ${isActive ? 'font-medium' : ''}`}>
              {item.label}
            </span>
            {isActive && (
              <div className="absolute bottom-0 w-6 h-1 bg-blue-600 rounded-t-full transform translate-y-0.5"></div>
            )}
          </Link>
        );
      })}
    </div>
  );
};

export default BottomNavigation;
/**
 * Calculate days, hours, minutes remaining until target date
 */
export const calculateTimeRemaining = (targetDate: Date): { 
  days: number; 
  hours: number; 
  minutes: number; 
  seconds: number;
} => {
  const currentTime = new Date().getTime();
  const targetTime = targetDate.getTime();
  const timeRemaining = targetTime - currentTime;
  
  // Calculate time units
  const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
  const hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);
  
  return { days, hours, minutes, seconds };
};

/**
 * Format time (HH:MM AM/PM)
 */
export const formatTime = (timeString: string): string => {
  const date = new Date(timeString);
  return date.toLocaleTimeString('en-US', { 
    hour: 'numeric', 
    minute: '2-digit', 
    hour12: true 
  });
};

/**
 * Get motivational tips randomly
 */
export const getMotivationalTip = (): string => {
  const tips = [
    "Consistency is key to success!",
    "Small progress is still progress!",
    "Stay focused on your goals today!",
    "Every study session brings you closer to success!",
    "Your dedication today will pay off tomorrow!",
    "Keep pushing, you're on the right track!",
    "You've got this! Stay committed to your schedule!",
    "Today's effort is tomorrow's achievement!"
  ];
  
  return tips[Math.floor(Math.random() * tips.length)];
};